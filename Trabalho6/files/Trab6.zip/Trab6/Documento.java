package trabalho6;

public class Documento extends Arquivo {
    public Documento(String nome, int endereco, int blocos) {
        super(nome, endereco, blocos);
    }
}
